

class ChatController {
    static send = () => {
        console.log("TEST");
    }
}